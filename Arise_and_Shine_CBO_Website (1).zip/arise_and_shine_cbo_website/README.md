# Arise & Shine CBO Website

A responsive, multi-page static website for Arise & Shine Community-Based Organization.

## Pages
- index.html — Home
- about.html — About
- programs.html — Our Work
- gallery.html — Gallery
- get-involved.html — Get Involved
- contact.html — Contact

## Included assets
- assets/logo.png — supplied CBO logo
- assets/community-forum.jpg — supplied community photo

## One thing to update before launch
Open `script.js` and replace:
REPLACE-WITH-CBO-EMAIL@example.com
with the CBO's real email address.

The contact form then opens a pre-filled email in the visitor's email application. For a true web-based submission form, the site can later be connected to Formspree, Netlify Forms, or another form backend.

## Free hosting
This is a static website and can be hosted on GitHub Pages, Netlify, Cloudflare Pages, or similar free hosting.

## Notes
No statistics, phone numbers, email addresses, donors, or impact figures were invented. Those can be added once supplied.
