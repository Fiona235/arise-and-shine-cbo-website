
const menu = document.querySelector(".menu");
const nav = document.querySelector(".nav-links");
if(menu && nav){
  menu.addEventListener("click",()=>{
    nav.classList.toggle("open");
    menu.setAttribute("aria-expanded", nav.classList.contains("open"));
  });
  nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
}

const observer = new IntersectionObserver((entries)=>{
  entries.forEach(entry=>{ if(entry.isIntersecting){ entry.target.classList.add("show"); observer.unobserve(entry.target); }});
},{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

const year = document.querySelector("#year");
if(year) year.textContent = new Date().getFullYear();

const form = document.querySelector("#contactForm");
if(form){
  form.addEventListener("submit",(e)=>{
    e.preventDefault();
    const name = document.querySelector("#name").value.trim();
    const email = document.querySelector("#email").value.trim();
    const message = document.querySelector("#message").value.trim();
    if(!name || !email || !message){
      alert("Please complete your name, email and message.");
      return;
    }
    // Replace this address with the CBO's real email address.
    const recipient = "ariseandshinecbo66@gmail.com";
    const subject = encodeURIComponent(`Website enquiry from ${name}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\n${message}`);
    if(recipient.includes("REPLACE-WITH")){
      alert("The website is ready, but the CBO email address still needs to be added to script.js before the contact form can send messages.");
      return;
    }
    window.location.href = `mailto:${recipient}?subject=${subject}&body=${body}`;
  });
}
