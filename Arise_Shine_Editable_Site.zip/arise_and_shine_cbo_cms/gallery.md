---
title: Gallery
permalink: /gallery/
---
<section class="page-hero"><div class="container reveal"><div class="breadcrumb">Arise &amp; Shine CBO / Gallery</div><h1>Community in action.</h1><p class="lead">A glimpse of the people and spaces at the heart of our work.</p></div></section><section class="section"><div class="container"><div class="gallery">{% for item in site.data.gallery %}<figure class="reveal"><img src="{{ item.image | relative_url }}" alt="{{ item.alt }}"><figcaption>{{ item.caption }}</figcaption></figure>{% endfor %}</div></div></section>