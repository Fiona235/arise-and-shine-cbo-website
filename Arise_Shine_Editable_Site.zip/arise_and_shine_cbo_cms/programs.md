---
title: Our Work
permalink: /programs/
---
<section class="page-hero"><div class="container reveal"><div class="breadcrumb">Arise &amp; Shine CBO / Our Work</div><h1>Our programs turn knowledge into action.</h1><p class="lead">From schools and farms to villages and youth groups, we work where community action can make a practical difference.</p></div></section><section class="section"><div class="container"><div class="grid-2">{% for p in site.data.programs %}<article class="card program-card reveal"><div class="icon">{{ p.icon }}</div><h3>{{ p.title }}</h3><p>{{ p.description }}</p><div class="learn">{{ p.line }}</div></article>{% endfor %}</div></div></section>