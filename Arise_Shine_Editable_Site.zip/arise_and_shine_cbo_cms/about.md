---
title: About Us
permalink: /about/
---
<section class="page-hero"><div class="container reveal"><div class="breadcrumb">Arise &amp; Shine CBO / About</div><h1>Rooted in community. Driven by sustainability.</h1><p class="lead">{{ site.data.site.location }}. We work to strengthen climate resilience and sustainable development.</p></div></section><section class="section"><div class="container split"><div class="reveal"><div class="eyebrow">Who we are</div><h2>Communities are at the heart of our work.</h2><p class="lead">{{ site.data.site.intro }}</p></div><div class="card reveal"><div class="icon">🌍</div><h3>Our mission</h3><p>{{ site.data.site.mission }}</p><div class="divider"></div><div class="icon">☀️</div><h3>Our vision</h3><p>{{ site.data.site.vision }}</p></div></div></section>