# Arise & Shine CBO — editable website

This version uses Jekyll for the public site and Pages CMS as a free GitHub-backed editor. Pages CMS provides a friendly editing interface for site settings, programs and gallery media.

## One-time setup
1. Create/sign into GitHub.
2. Create a repository, e.g. `arise-and-shine-cbo-website`.
3. Upload the contents of this folder to the repository on the `main` branch.
4. In GitHub Settings → Pages, choose GitHub Actions if prompted.
5. Open https://app.pagescms.org/, sign in with GitHub, install its GitHub App for the repository when prompted, and open the repository.
6. Use Site Settings, Programs and Gallery in Pages CMS. Saving writes changes to GitHub; GitHub Pages rebuilds the public site.

Contact details are already configured: ariseandshinecbo66@gmail.com / +254 745 124 321.
